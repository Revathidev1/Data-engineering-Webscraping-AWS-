
CREATE DATABASE API_project;

USE API_project;
CREATE TABLE weather_condition (
	city_id INT ,
    city VARCHAR(15),   
    temp FLOAT(6),
    feels_like FLOAT(6), 
    wind_speed FLOAT(6), 
    forecast_time DATETIME,
    rain_prob FLOAT(6),
    outlook VARCHAR(15),
    PRIMARY KEY (city_id)
);
DROP DATABASE sql_workshop ;   
DROP table weather_condition;
DROP table cities;

   CREATE TABLE IF NOT EXISTS cities (
	city_id INT AUTO_INCREMENT,
    city VARCHAR(15),
    country VARCHAR(15),
    population INT,
    lat FLOAT(6), 
    lon FLOAT(6), 
    PRIMARY KEY (city_id)
);