CREATE DATABASE sql_workshop;
USE sql_workshop;
DROP table iss_status;
DROP table iss_logs;

CREATE TABLE iss_status (
	iss_timestamp DATETIME,
    activity_status VARCHAR(50),
    PRIMARY KEY (iss_timestamp)
);

CREATE TABLE iss_logs (
	id INT AUTO_INCREMENT, 
    latitude FLOAT(6), 
    longitude FLOAT(6), 
    iss_timestamp DATETIME,
    PRIMARY KEY (id),
    FOREIGN KEY (iss_timestamp) REFERENCES iss_status(iss_timestamp)
);

