USE API_project;
 CREATE TABLE airports (
	city_id INT AUTO_INCREMENT,
    icao VARCHAR(15),
    PRIMARY KEY (city_id)
   
);

-- drop table airport;


