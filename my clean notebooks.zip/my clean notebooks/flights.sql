USE API_project;
CREATE TABLE  flights (
    -- flight_id INT AUTO_INCREMENT,
    ICAO VARCHAR(15),
	departure_airport VARCHAR(50),
    local_time DATETIME,   
    PRIMARY KEY (ICAO)
	-- FOREIGN KEY (flight_id) REFERENCES airport(city_id)
);

 -- drop table flight;




